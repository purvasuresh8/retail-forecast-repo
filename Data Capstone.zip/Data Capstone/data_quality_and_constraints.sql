-- 1) Ensure NOT NULL on critical fields in clean_sales (completeness)
alter table retail.clean_sales
alter column FirstName
set not null,
alter column LastName
set not null,
alter column Email
set not null,
alter column ProductCode
set not null,
alter column Price
set not null,
alter column TransactionAmount
set not null,
alter column TransactionDate
set not null;

-- 2) Accuracy/validity checks
-- First, drop any old constraints if they exist
alter table retail.clean_sales
drop constraint IF exists chk_price_nonnegative,
drop constraint IF exists chk_discount_range,
drop constraint IF exists chk_transaction_amount_nonnegative;

-- Recreate valid constraints
alter table retail.clean_sales
add constraint chk_price_nonnegative check (Price >= 0),
add constraint chk_discount_range check (
  Discount >= 0
  and Discount <= 100
);

-- Remove rows with invalid Price values
delete from retail.clean_sales
where
  Price < 0;

-- 4) Consistency
alter table retail.clean_sales
add constraint chk_phone_length check (char_length(coalesce(PhoneNumber, '')) <= 50);

-- 5) Timeliness
alter table retail.clean_sales
add constraint chk_transaction_not_future check (TransactionDate <= NOW()),
add constraint chk_transaction_recent check (TransactionDate >= (NOW() - INTERVAL '20 years'));

-- 6) Valid email format 
alter table retail.clean_sales
add constraint chk_email_format check (
  Email ~* '^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}$'
);

-- 7) Indexes to speed queries
create index IF not exists idx_clean_sales_transaction_date on retail.clean_sales (TransactionDate);

create index IF not exists idx_clean_sales_product_code on retail.clean_sales (ProductCode);

create index IF not exists idx_clean_sales_city_state on retail.clean_sales (City, State);

-- 8) Indexes on raw table
create index IF not exists idx_raw_sales_transaction_date on retail.raw_sales (TransactionDate);

create index IF not exists idx_raw_sales_product_code on retail.raw_sales (ProductCode);