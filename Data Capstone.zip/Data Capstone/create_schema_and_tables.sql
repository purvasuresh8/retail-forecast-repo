-- 01_create_schema_and_tables.sql
-- Create schema
create schema IF not exists retail;

-- Raw staging table (as uploaded from CSV)
create table if not exists retail.raw_sales (
  ID BIGINT primary key,
  FirstName VARCHAR(100),
  LastName VARCHAR(100),
  PhoneNumber VARCHAR(50),
  Email VARCHAR(254),
  Gender VARCHAR(20),
  MaritalStatus VARCHAR(50),
  Street VARCHAR(255),
  City VARCHAR(100),
  State VARCHAR(100),
  PostalCode VARCHAR(50),
  ProductCode VARCHAR(100),
  Price NUMERIC(12, 2),
  Discount NUMERIC(6, 2),
  SKU VARCHAR(100),
  TransactionAmount NUMERIC(14, 2),
  TransactionDate TIMESTAMP
);

-- Clean / validated table
create table if not exists retail.clean_sales (
  ID BIGINT primary key,
  FirstName VARCHAR(100) not null,
  LastName VARCHAR(100) not null,
  PhoneNumber VARCHAR(50),
  Email VARCHAR(254) not null,
  Gender VARCHAR(20),
  MaritalStatus VARCHAR(50),
  Street VARCHAR(255),
  City VARCHAR(100),
  State VARCHAR(100),
  PostalCode VARCHAR(50),
  ProductCode VARCHAR(100) not null,
  Price NUMERIC(12, 2) not null,
  Discount NUMERIC(6, 2) default 0,
  SKU VARCHAR(100),
  TransactionAmount NUMERIC(14, 2) not null,
  TransactionDate TIMESTAMP not null
);

-- Feature-engineered / aggregated table (example: monthly aggregates per product)
create table if not exists retail.feature_sales (
  ID SERIAL primary key,
  FirstName VARCHAR(100) not null,
  LastName VARCHAR(100) not null,
  PhoneNumber VARCHAR(50),
  Email VARCHAR(255) not null,
  Gender VARCHAR(20),
  MaritalStatus VARCHAR(20),
  Street VARCHAR(255),
  City VARCHAR(100),
  State VARCHAR(100),
  PostalCode VARCHAR(20),
  ProductCode VARCHAR(100) not null,
  Price NUMERIC(10, 2) not null check (Price >= 0),
  Discount NUMERIC(5, 2) check (
    Discount >= 0
    and Discount <= 100
  ),
  SKU VARCHAR(100),
  TransactionAmount NUMERIC(12, 2) not null,
  TransactionDate TIMESTAMP not null,
  Transaction_Year INT,
  Transaction_Month INT,
  Transaction_Day INT,
  Transaction_Weekday VARCHAR(15),
  Revenue NUMERIC(14, 2),
  Total_Revenue NUMERIC(14, 2),
  Customer_Segment VARCHAR(100)
);

-- Forecast results table
create table if not exists retail.sales_forecast (
  sales_date DATE not null, -- date of forecast
  actual NUMERIC(16, 6), -- actual observed value
  pred_lgb NUMERIC(16, 6), -- LightGBM forecast
  pred_naive NUMERIC(16, 6)
);
